#include <stdio.h>

/* PURPOSE:
 *     This program is mean to show a basic C program.
 *     All it does is print "Hello World!" to the
 *     screen and exit.
 * /

/* Main Program */
int main(int argc, char **argv)
{
    /* Print our string to standard output */
    puts("Hello World!\n");

    /* Exit with status 0 */
    return 0;
}
