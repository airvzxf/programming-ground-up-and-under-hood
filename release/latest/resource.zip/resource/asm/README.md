# Programming from the ground up

## Source files

It's easy, only needs to execute `./make.sh` in this directory and it
will assemble and link all the souce files. The files with the
suffix `-bin` are the executables.
